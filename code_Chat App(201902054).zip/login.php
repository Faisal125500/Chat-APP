<?php
$link = mysqli_connect("localhost", "root", "", "chat_app");

if (!$link) {
    die("Connection failed: ". mysqli_connect_error());
}
if (isset($_POST['login'])) {
  // Escape user inputs for security
  $username = mysqli_real_escape_string($link, $_POST['username']);
  $password = mysqli_real_escape_string($link, $_POST['password']);

  // Query the database to check if the user exists
  $sql = "SELECT * FROM users WHERE username = '$username'";
  $result = mysqli_query($link, $sql);
  if (mysqli_num_rows($result) > 0) {
    $user_data = mysqli_fetch_assoc($result);
    if (password_verify($password, $user_data['password'])) {
      // Login successful, start a session
      session_start();
      $_SESSION['username'] = $username;
      header('Location: Group_chat.php');
      exit;
    } else {
      echo "<div class='alert alert-danger'>Invalid password!</div>";
    }
  } else {
    echo "<div class='alert alert-danger'>User not found!</div>";
  }
}

// Close connection
mysqli_close($link);
?>

<!-- Login form -->
<style>
  body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
  }
 .container {
    max-width: 300px;
    margin: 40px auto;
    padding: 20px;
    background-color: #fff;
    border: 1px solid #ddd;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }
 .form-group {
    margin-bottom: 20px;
  }
 .form-control {
    width: 100%;
    height: 40px;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
  }
 .btn {
    width: 100%;
    height: 40px;
    padding: 10px;
    font-size: 16px;
    background-color: #4CAF50;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }
  .btn1 {
    width: 100%;
    height: 40px;
    padding: 10px;
    font-size: 16px;
    background-color: #183397;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    
  }  
 .btn:hover {
    background-color: #3e8e41;
  }
 .alert {
    padding: 10px;
    background-color: #f0f0f0;
    border: 1px solid #ccc;
    border-radius: 5px;
    margin-bottom: 20px;
  }
 .alert-danger {
    background-color: #ff9999;
    border-color: #ff6666;
  }
</style>

<div class="container">
  <h2>Login</h2>
  <form action="login.php" method="post">
    <div class="form-group">
      <label for="username">Username:</label>
      <input type="text" id="username" name="username" class="form-control">
    </div>
    <div class="form-group">
      <label for="password">Password:</label>
      <input type="password" id="password" name="password" class="form-control">
    </div>
    <input type="submit" name="login" value="Login" class="btn">
    <a href="home.html" class="btn1 btn-home">Home</a>
  </form>
</div>