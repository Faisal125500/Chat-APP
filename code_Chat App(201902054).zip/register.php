<?php
$link = mysqli_connect("localhost", "root", "", "chat_app");

if (!$link) {
    die("Connection failed: ". mysqli_connect_error());
}
if (isset($_POST['register'])) {
  // Escape user inputs for security
  $username = mysqli_real_escape_string($link, $_POST['username']);
  $email = mysqli_real_escape_string($link, $_POST['email']);
  $password = mysqli_real_escape_string($link, $_POST['password']);
  $confirm_password = mysqli_real_escape_string($link, $_POST['confirm_password']);

  // Check if passwords match
  if ($password!= $confirm_password) {
    echo "<div class='alert alert-danger'>Passwords do not match!</div>";
    exit;
  }

  // Hash the password
  $hashed_password = password_hash($password, PASSWORD_DEFAULT);

  // Insert user into the database
  $sql = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$hashed_password')";
  if (mysqli_query($link, $sql)) {
    echo "<div class='alert alert-success'>User registered successfully!</div>";
  } else {
    echo "<div class='alert alert-danger'>Error registering user: ". mysqli_error($link)."</div>";
  }
}

// Close connection
mysqli_close($link);
?>

<!-- Registration form -->
<style>
  body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0;
  }
.container {
    max-width: 300px;
    margin: 40px auto;
    padding: 20px;
    background-color: #fff;
    border: 1px solid #ddd;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }
.form-group {
    margin-bottom: 20px;
  }
.form-control {
    width: 100%;
    height: 40px;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
  }
.btn {
    width: 100%;
    height: 40px;
    padding: 10px;
    font-size: 16px;
    background-color: #4CAF50;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }
  .btn1 {
    width: 100%;
    height: 40px;
    padding: 10px;
    font-size: 16px;
    background-color: #183397;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    
  }  

.btn:hover {
    background-color: #3e8e41;
  }
.alert {
    padding: 10px;
    background-color: #f0f0f0;
    border: 1px solid #ccc;
    border-radius: 5px;
    margin-bottom: 20px;
  }
.alert-success {
    background-color: #dff0df;
    border-color: #c6f7c6;
  }
.alert-danger {
    background-color: #ff9999;
    border-color: #ff6666;
  }
</style>

<div class="container">
  <h2>Register</h2>
  

  <form action="register.php" method="post">
    <div class="form-group">
      <label for="username">Username:</label>
      <input type="text" id="username" name="username" class="form-control">
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" id="email" name="email" class="form-control">
    </div>
    <div class="form-group">
      <label for="password">Password:</label>
      <input type="password" id="password" name="password" class="form-control">
    </div>
    <div class="form-group">
      <label for="confirm_password">Confirm Password:</label>
      <input type="password" id="confirm_password" name="confirm_password" class="form-control">
    </div>
    <input type="submit" name="register" value="Register" class="btn">
    <a href="home.html" class="btn1 btn-home">Home</a>
  </form>
</div>