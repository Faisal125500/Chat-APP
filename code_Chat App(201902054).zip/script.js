document.addEventListener("DOMContentLoaded", function() {
	const loginBtn = document.getElementById("login-btn");
	const registerBtn = document.getElementById("register-btn");

	loginBtn.addEventListener("click", function() {
		window.location.href = "login.php";
	});

	registerBtn.addEventListener("click", function() {
		window.location.href = "register.php";
	});
});